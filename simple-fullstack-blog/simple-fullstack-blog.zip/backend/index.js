require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./src/db');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

// Health
app.get('/health', (req, res) => res.json({status: 'ok'}));

// Get posts
app.get('/posts', async (req, res) => {
  try {
    const posts = await db('posts').select('*').orderBy('created_at', 'desc');
    res.json(posts);
  } catch (err) {
    console.error(err);
    res.status(500).json({error: 'database error'});
  }
});

// Create post
app.post('/posts', async (req, res) => {
  const { title, body } = req.body;
  if (!title || !body) return res.status(400).json({error: 'title and body required'});
  try {
    const [id] = await db('posts').insert({ title, body }).returning('id');
    const post = await db('posts').where({ id }).first();
    res.status(201).json(post);
  } catch (err) {
    console.error(err);
    res.status(500).json({error: 'database error'});
  }
});

app.listen(PORT, () => {
  console.log(`Backend listening on port ${PORT}`);
});