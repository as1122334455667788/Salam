import React, { useEffect, useState } from 'react';
import PostList from './components/PostList';
import NewPostForm from './components/NewPostForm';
import api from './api';

export default function App() {
  const [posts, setPosts] = useState([]);

  async function fetchPosts() {
    try {
      const res = await api.get('/posts');
      setPosts(res.data);
    } catch (e) {
      console.error(e);
    }
  }

  useEffect(() => { fetchPosts(); }, []);

  async function handleCreate(post) {
    try {
      await api.post('/posts', post);
      fetchPosts();
    } catch (e) { console.error(e); }
  }

  return (
    <div style={{maxWidth: 800, margin: '40px auto', fontFamily: 'Arial, sans-serif'}}>
      <h1>Simple Blog</h1>
      <NewPostForm onCreate={handleCreate} />
      <hr />
      <PostList posts={posts} />
    </div>
  );
}