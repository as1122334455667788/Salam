import React, { useState } from 'react';

export default function NewPostForm({ onCreate }) {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');

  function submit(e) {
    e.preventDefault();
    if (!title || !body) return alert('title and body required');
    onCreate({ title, body });
    setTitle('');
    setBody('');
  }

  return (
    <form onSubmit={submit} style={{marginBottom: 20}}>
      <div>
        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" style={{width: '100%', padding: 8}} />
      </div>
      <div style={{marginTop: 8}}>
        <textarea value={body} onChange={e => setBody(e.target.value)} placeholder="Write your post..." rows={5} style={{width: '100%', padding: 8}} />
      </div>
      <div style={{marginTop: 8}}>
        <button type="submit">Create Post</button>
      </div>
    </form>
  );
}