import React from 'react';

export default function PostList({ posts }) {
  if (!posts || posts.length === 0) return <p>No posts yet.</p>;
  return (
    <div>
      {posts.map(p => (
        <div key={p.id} style={{marginBottom: 20}}>
          <h3>{p.title}</h3>
          <small>{new Date(p.created_at).toLocaleString()}</small>
          <p>{p.body}</p>
        </div>
      ))}
    </div>
  );
}